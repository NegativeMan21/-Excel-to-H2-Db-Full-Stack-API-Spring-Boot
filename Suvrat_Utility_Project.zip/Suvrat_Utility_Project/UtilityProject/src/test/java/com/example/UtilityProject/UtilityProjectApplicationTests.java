package com.example.UtilityProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UtilityProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
